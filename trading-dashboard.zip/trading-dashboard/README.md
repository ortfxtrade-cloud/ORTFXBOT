# Signal Scanner Dashboard

React frontend for the Telegram trading bot, per the handoff spec. Talks to a
Flask backend over REST (`/api/*`) and Socket.IO (`/signals` namespace).

## Setup

```bash
npm install
npm run dev
```

The dev server proxies `/api` and `/socket.io` to `http://localhost:5000`
(see `vite.config.js`) — point that at wherever your Flask backend runs.

## Structure

```
src/
  api/client.js        All REST calls (axios), one function per endpoint
  socket/socket.js      Socket.IO connection + event name constants
  context/AppContext.jsx  Global state (useReducer) + socket wiring + polling fallback
  theme/theme.js         MUI dark theme
  components/
    Layout/               Sidebar, Topbar (scanner toggle, connection status)
    Dashboard/             Overview page
    Signals/               Signal feed + card
    Pairs/                 Add/remove pairs, blocked indicator
    Settings/              Global + per-pair RSI thresholds
    Statistics/             Win rate, per-pair delays, loss-reason chart
    Modals/                Entry time, Conditions, Feedback/Loss interview, Chat
```

## Notes / assumptions made where the spec was silent

- `GET /api/settings` is assumed to return `{ global: {...}, perPair: { SYMBOL: {...} } }`.
  Adjust `SettingsPage.jsx` if your backend shape differs.
- `GET /api/conditions/:symbol` is assumed to return `{ report: "✅ ...\n❌ ..." }`
  (a newline-delimited text report, as described in the spec). If it's
  structured JSON instead, swap the parser in `ConditionsModal.jsx`.
- `GET /api/stats` is assumed to return
  `{ total_trades, wins, losses, loss_reasons: { reason: count }, per_pair: [{ symbol, avg_delay_win, avg_delay_loss }] }`.
- The scanner start/pause button optimistically shows a spinner but waits for
  the `scanner_status` websocket event to actually flip the toggle, so the UI
  never claims a state the backend hasn't confirmed.
- `POST /api/control/scanner` action strings are assumed to be `"start"` / `"pause"`.
