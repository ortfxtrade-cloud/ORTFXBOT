import React, { useState } from 'react';
import { Box, Container, Fab } from '@mui/material';
import ChatIcon from '@mui/icons-material/ChatBubbleOutline';
import Sidebar from './components/Layout/Sidebar';
import Topbar from './components/Layout/Topbar';
import Dashboard from './components/Dashboard/Dashboard';
import SignalFeed from './components/Signals/SignalFeed';
import PairManagement from './components/Pairs/PairManagement';
import SettingsPage from './components/Settings/SettingsPage';
import StatisticsPage from './components/Statistics/StatisticsPage';
import ChatModal from './components/Modals/ChatModal';

const VIEWS = {
  dashboard: Dashboard,
  signals: SignalFeed,
  pairs: PairManagement,
  settings: SettingsPage,
  stats: StatisticsPage,
};

export default function App() {
  const [view, setView] = useState('dashboard');
  const [chatOpen, setChatOpen] = useState(false);
  const ActiveView = VIEWS[view];

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <Sidebar current={view} onNavigate={setView} />
      <Box sx={{ flexGrow: 1 }}>
        <Topbar />
        <Container maxWidth="lg" sx={{ py: 3 }}>
          <ActiveView onNavigate={setView} />
        </Container>
      </Box>

      <Fab
        color="primary"
        onClick={() => setChatOpen(true)}
        sx={{ position: 'fixed', bottom: 24, right: 24 }}
      >
        <ChatIcon />
      </Fab>
      <ChatModal open={chatOpen} onClose={() => setChatOpen(false)} />
    </Box>
  );
}
