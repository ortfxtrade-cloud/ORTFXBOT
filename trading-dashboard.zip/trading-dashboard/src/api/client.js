import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  timeout: 15000,
});

// Central place to normalize errors so components can show one toast shape.
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const message =
      err.response?.data?.message || err.message || 'Request failed';
    return Promise.reject({ ...err, message });
  }
);

export const PairsAPI = {
  list: () => api.get('/pairs'),
  add: (symbol) => api.post('/pairs', { symbol }),
  remove: (symbol) => api.delete(`/pairs/${symbol}`),
};

export const SignalsAPI = {
  latest: (limit = 20) => api.get('/signals/latest', { params: { limit } }),
  get: (msgId) => api.get(`/signals/${msgId}`),
  conditions: (symbol) => api.get(`/conditions/${symbol}`),
  quickScan: (symbol) => api.get(`/quick_scan/${symbol}`),
};

export const SettingsAPI = {
  get: () => api.get('/settings'),
  update: (payload) => api.post('/settings', payload),
};

export const StatsAPI = {
  get: () => api.get('/stats'),
};

export const FeedbackAPI = {
  submit: (payload) => api.post('/feedback', payload),
};

export const EntryTimeAPI = {
  record: (msgId, time) => api.post('/entry_time', { msgId, time }),
};

export const ChatAPI = {
  send: (message, mode) => api.post('/chat', { message, mode }),
};

export const ControlAPI = {
  scanner: (action) => api.post('/control/scanner', { action }),
  mute: (symbol) => api.post(`/control/mute/${symbol}`),
};

export default api;
