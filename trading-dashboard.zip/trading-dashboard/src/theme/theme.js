import { createTheme } from '@mui/material/styles';

// Dark theme with a signal-forward palette: green/red carry real meaning
// (buy/sell, win/loss) so they're reserved for that purpose only elsewhere.
const theme = createTheme({
  palette: {
    mode: 'dark',
    background: {
      default: '#0B0E14',
      paper: '#131722',
    },
    primary: { main: '#4C8DFF' },
    success: { main: '#26A69A' }, // BUY / WIN
    error: { main: '#EF5350' },   // SELL / LOSS
    warning: { main: '#F5A623' }, // blocked / muted
    text: {
      primary: '#E6E9F0',
      secondary: '#8993A8',
    },
    divider: 'rgba(230,233,240,0.08)',
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h6: { fontWeight: 600 },
    subtitle2: { fontWeight: 600, letterSpacing: 0.3 },
    caption: { color: '#8993A8' },
  },
  shape: { borderRadius: 10 },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: { backgroundImage: 'none' },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          border: '1px solid rgba(230,233,240,0.08)',
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: { textTransform: 'none', fontWeight: 600 },
      },
    },
  },
});

export default theme;
