import { io } from 'socket.io-client';

let socket = null;

// Lazily create a single shared socket connection to the /signals namespace.
// reconnectionDelayMax gives us exponential-ish backoff out of the box;
// we still expose connect/disconnect so components don't each own a socket.
export function getSocket() {
  if (!socket) {
    socket = io('/signals', {
      autoConnect: false,
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 15000,
      randomizationFactor: 0.5,
    });
  }
  return socket;
}

export function connectSocket() {
  const s = getSocket();
  if (!s.connected) s.connect();
  return s;
}

export function disconnectSocket() {
  if (socket?.connected) socket.disconnect();
}

// Server -> client events, per the spec:
//   new_signal, blocked_update, scanner_status, signal_update
export const SOCKET_EVENTS = {
  NEW_SIGNAL: 'new_signal',
  BLOCKED_UPDATE: 'blocked_update',
  SCANNER_STATUS: 'scanner_status',
  SIGNAL_UPDATE: 'signal_update',
  CONNECT: 'connect',
  DISCONNECT: 'disconnect',
  CONNECT_ERROR: 'connect_error',
};
