import React, {
  createContext,
  useContext,
  useEffect,
  useReducer,
  useRef,
  useCallback,
} from 'react';
import { useSnackbar } from 'notistack';
import { PairsAPI, SignalsAPI, StatsAPI, SettingsAPI } from '../api/client';
import {
  connectSocket,
  disconnectSocket,
  getSocket,
  SOCKET_EVENTS,
} from '../socket/socket';

const AppContext = createContext(null);

const initialState = {
  pairs: [],
  blockedPairs: [],
  signals: [],
  stats: null,
  settings: null,
  scannerRunning: false,
  connectionStatus: 'connecting', // connecting | live | polling | offline
  loading: { pairs: true, signals: true, stats: true, settings: true },
  unreadCount: 0,
};

function reducer(state, action) {
  switch (action.type) {
    case 'SET_LOADING':
      return {
        ...state,
        loading: { ...state.loading, [action.key]: action.value },
      };
    case 'SET_PAIRS':
      return { ...state, pairs: action.payload, loading: { ...state.loading, pairs: false } };
    case 'ADD_PAIR':
      return { ...state, pairs: [...state.pairs, action.payload] };
    case 'REMOVE_PAIR':
      return {
        ...state,
        pairs: state.pairs.filter((p) => p.symbol !== action.symbol),
      };
    case 'SET_SIGNALS':
      return { ...state, signals: action.payload, loading: { ...state.loading, signals: false } };
    case 'PREPEND_SIGNAL':
      return {
        ...state,
        signals: [action.payload, ...state.signals].slice(0, 100),
        unreadCount: state.unreadCount + 1,
      };
    case 'UPDATE_SIGNAL':
      return {
        ...state,
        signals: state.signals.map((s) =>
          s.msg_id === action.payload.msg_id ? { ...s, ...action.payload } : s
        ),
      };
    case 'REMOVE_SIGNAL_SYMBOL':
      return {
        ...state,
        signals: state.signals.filter((s) => s.symbol !== action.symbol),
      };
    case 'SET_BLOCKED':
      return { ...state, blockedPairs: action.payload };
    case 'SET_SCANNER_STATUS':
      return { ...state, scannerRunning: action.payload };
    case 'SET_STATS':
      return { ...state, stats: action.payload, loading: { ...state.loading, stats: false } };
    case 'SET_SETTINGS':
      return { ...state, settings: action.payload, loading: { ...state.loading, settings: false } };
    case 'SET_CONNECTION_STATUS':
      return { ...state, connectionStatus: action.payload };
    case 'CLEAR_UNREAD':
      return { ...state, unreadCount: 0 };
    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  const { enqueueSnackbar } = useSnackbar();
  const pollRef = useRef(null);

  const notifyError = useCallback(
    (msg) => enqueueSnackbar(msg, { variant: 'error' }),
    [enqueueSnackbar]
  );

  // Initial parallel load
  useEffect(() => {
    (async () => {
      const results = await Promise.allSettled([
        PairsAPI.list(),
        SignalsAPI.latest(20),
        StatsAPI.get(),
        SettingsAPI.get(),
      ]);
      const [pairsRes, signalsRes, statsRes, settingsRes] = results;

      if (pairsRes.status === 'fulfilled') {
        dispatch({ type: 'SET_PAIRS', payload: pairsRes.value.data });
      } else {
        dispatch({ type: 'SET_LOADING', key: 'pairs', value: false });
        notifyError('Failed to load pairs');
      }

      if (signalsRes.status === 'fulfilled') {
        dispatch({ type: 'SET_SIGNALS', payload: signalsRes.value.data });
      } else {
        dispatch({ type: 'SET_LOADING', key: 'signals', value: false });
        notifyError('Failed to load signals');
      }

      if (statsRes.status === 'fulfilled') {
        dispatch({ type: 'SET_STATS', payload: statsRes.value.data });
      } else {
        dispatch({ type: 'SET_LOADING', key: 'stats', value: false });
        notifyError('Failed to load statistics');
      }

      if (settingsRes.status === 'fulfilled') {
        dispatch({ type: 'SET_SETTINGS', payload: settingsRes.value.data });
      } else {
        dispatch({ type: 'SET_LOADING', key: 'settings', value: false });
        notifyError('Failed to load settings');
      }
    })();
  }, [notifyError]);

  // Polling fallback — only active while connectionStatus !== 'live'
  const startPolling = useCallback(() => {
    if (pollRef.current) return;
    dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'polling' });
    pollRef.current = setInterval(async () => {
      try {
        const res = await SignalsAPI.latest(20);
        dispatch({ type: 'SET_SIGNALS', payload: res.data });
      } catch {
        // stay quiet on individual poll failures; the toast would get noisy
      }
    }, 15000);
  }, []);

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }, []);

  // Socket wiring
  useEffect(() => {
    const socket = connectSocket();

    socket.on(SOCKET_EVENTS.CONNECT, () => {
      dispatch({ type: 'SET_CONNECTION_STATUS', payload: 'live' });
      stopPolling();
    });

    socket.on(SOCKET_EVENTS.DISCONNECT, () => {
      startPolling();
    });

    socket.on(SOCKET_EVENTS.CONNECT_ERROR, () => {
      startPolling();
    });

    socket.on(SOCKET_EVENTS.NEW_SIGNAL, (signal) => {
      dispatch({ type: 'PREPEND_SIGNAL', payload: signal });
    });

    socket.on(SOCKET_EVENTS.BLOCKED_UPDATE, (blocked) => {
      dispatch({ type: 'SET_BLOCKED', payload: blocked });
    });

    socket.on(SOCKET_EVENTS.SCANNER_STATUS, (status) => {
      dispatch({ type: 'SET_SCANNER_STATUS', payload: status.running ?? status });
    });

    socket.on(SOCKET_EVENTS.SIGNAL_UPDATE, (signal) => {
      dispatch({ type: 'UPDATE_SIGNAL', payload: signal });
    });

    // Fallback: if we haven't connected within 5s, start polling immediately
    const fallbackTimer = setTimeout(() => {
      if (!socket.connected) startPolling();
    }, 5000);

    return () => {
      clearTimeout(fallbackTimer);
      socket.off();
      disconnectSocket();
      stopPolling();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const actions = {
    addPair: async (symbol) => {
      const res = await PairsAPI.add(symbol);
      dispatch({ type: 'ADD_PAIR', payload: res.data });
      enqueueSnackbar(`${symbol} added`, { variant: 'success' });
    },
    removePair: async (symbol) => {
      await PairsAPI.remove(symbol);
      dispatch({ type: 'REMOVE_PAIR', symbol });
      dispatch({ type: 'REMOVE_SIGNAL_SYMBOL', symbol });
      enqueueSnackbar(`${symbol} removed`, { variant: 'info' });
    },
    updateSettings: async (payload) => {
      const res = await SettingsAPI.update(payload);
      dispatch({ type: 'SET_SETTINGS', payload: res.data });
      enqueueSnackbar('Settings saved', { variant: 'success' });
    },
    refreshStats: async () => {
      const res = await StatsAPI.get();
      dispatch({ type: 'SET_STATS', payload: res.data });
    },
    clearUnread: () => dispatch({ type: 'CLEAR_UNREAD' }),
    notifyError,
    getSocket,
  };

  return (
    <AppContext.Provider value={{ state, dispatch, actions }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
