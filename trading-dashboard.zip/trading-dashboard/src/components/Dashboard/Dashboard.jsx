import React from 'react';
import { Box, Grid, Paper, Typography, Chip, Stack } from '@mui/material';
import { useApp } from '../../context/AppContext';
import SignalCard from '../Signals/SignalCard';

function SummaryCard({ label, value, color }) {
  return (
    <Paper sx={{ p: 2.5 }}>
      <Typography variant="caption">{label}</Typography>
      <Typography variant="h5" fontWeight={700} color={color}>
        {value}
      </Typography>
    </Paper>
  );
}

export default function Dashboard({ onNavigate }) {
  const { state } = useApp();
  const recent = state.signals.slice(0, 3);

  return (
    <Box>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={3}>
          <SummaryCard
            label="Scanner"
            value={state.scannerRunning ? 'Running' : 'Paused'}
            color={state.scannerRunning ? 'success.main' : 'text.secondary'}
          />
        </Grid>
        <Grid item xs={6} sm={3}>
          <SummaryCard label="Pairs tracked" value={state.pairs.length} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <SummaryCard label="Blocked" value={state.blockedPairs.length} color="warning.main" />
        </Grid>
        <Grid item xs={6} sm={3}>
          <SummaryCard label="Signals today" value={state.signals.length} />
        </Grid>
      </Grid>

      <Box sx={{ display: 'flex', alignItems: 'center', mb: 1.5 }}>
        <Typography variant="subtitle2">Latest signals</Typography>
        <Chip
          size="small"
          label="View all"
          onClick={() => onNavigate('signals')}
          sx={{ ml: 1.5, cursor: 'pointer' }}
          variant="outlined"
        />
      </Box>

      {recent.length === 0 ? (
        <Typography color="text.secondary">No signals yet.</Typography>
      ) : (
        <Stack spacing={2}>
          {recent.map((signal) => (
            <SignalCard
              key={signal.msg_id}
              signal={signal}
              onPlaceTrade={() => onNavigate('signals')}
              onConditions={() => onNavigate('signals')}
              onQuickScan={() => onNavigate('signals')}
              onFeedback={() => onNavigate('signals')}
            />
          ))}
        </Stack>
      )}
    </Box>
  );
}
