import React, { useState } from 'react';
import {
  Box,
  Paper,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Chip,
  Typography,
  CircularProgress,
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import { useApp } from '../../context/AppContext';
import ConditionsModal from '../Modals/ConditionsModal';

export default function PairManagement() {
  const { state, actions } = useApp();
  const [symbol, setSymbol] = useState('');
  const [adding, setAdding] = useState(false);
  const [conditionsTarget, setConditionsTarget] = useState(null);

  const handleAdd = async () => {
    const clean = symbol.trim().toUpperCase();
    if (!clean) return;
    setAdding(true);
    try {
      await actions.addPair(clean);
      setSymbol('');
    } catch (e) {
      actions.notifyError(e.message || `Failed to add ${clean}`);
    } finally {
      setAdding(false);
    }
  };

  const blockedSet = new Set(state.blockedPairs.map((b) => b.symbol ?? b));

  return (
    <Box sx={{ maxWidth: 560 }}>
      <Paper sx={{ p: 2, mb: 2, display: 'flex', gap: 1 }}>
        <TextField
          size="small"
          fullWidth
          placeholder="Symbol, e.g. EURUSD=X"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
        />
        <Button
          variant="contained"
          startIcon={adding ? <CircularProgress size={16} color="inherit" /> : <AddIcon />}
          onClick={handleAdd}
          disabled={adding}
        >
          Add
        </Button>
      </Paper>

      <Paper>
        {state.loading.pairs ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
            <CircularProgress size={24} />
          </Box>
        ) : state.pairs.length === 0 ? (
          <Typography color="text.secondary" sx={{ p: 3, textAlign: 'center' }}>
            No pairs yet. Add one above to start scanning.
          </Typography>
        ) : (
          <List disablePadding>
            {state.pairs.map((pair) => {
              const sym = pair.symbol ?? pair;
              const isBlocked = blockedSet.has(sym);
              return (
                <ListItem
                  key={sym}
                  divider
                  secondaryAction={
                    <Box sx={{ display: 'flex', gap: 0.5 }}>
                      <IconButton
                        size="small"
                        onClick={() => setConditionsTarget({ symbol: sym })}
                      >
                        <InfoOutlinedIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" onClick={() => actions.removePair(sym)}>
                        <DeleteOutlineIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  }
                >
                  <ListItemText primary={sym} />
                  {isBlocked && <Chip size="small" label="Blocked" color="warning" />}
                </ListItem>
              );
            })}
          </List>
        )}
      </Paper>

      <ConditionsModal
        signal={conditionsTarget}
        open={Boolean(conditionsTarget)}
        onClose={() => setConditionsTarget(null)}
      />
    </Box>
  );
}
