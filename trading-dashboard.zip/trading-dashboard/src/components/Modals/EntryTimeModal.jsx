import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Typography,
} from '@mui/material';
import { EntryTimeAPI } from '../../api/client';
import { useApp } from '../../context/AppContext';

function nowHHMM() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export default function EntryTimeModal({ signal, open, onClose }) {
  const { actions } = useApp();
  const [time, setTime] = useState(nowHHMM());
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (open) setTime(nowHHMM());
  }, [open]);

  if (!signal) return null;

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      await EntryTimeAPI.record(signal.msg_id, time);
      onClose();
    } catch (e) {
      actions.notifyError(e.message || 'Failed to record entry time');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>Place Trade — {signal.symbol}</DialogTitle>
      <DialogContent>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          Record the time you placed this trade. The scanner will auto-check
          the exit after the configured window.
        </Typography>
        <TextField
          label="Entry time"
          type="time"
          value={time}
          onChange={(e) => setTime(e.target.value)}
          fullWidth
          InputLabelProps={{ shrink: true }}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={handleSubmit} disabled={submitting}>
          Confirm
        </Button>
      </DialogActions>
    </Dialog>
  );
}
