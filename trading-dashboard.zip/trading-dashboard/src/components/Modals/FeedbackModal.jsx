import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Stack,
  Stepper,
  Step,
  StepLabel,
} from '@mui/material';
import { FeedbackAPI } from '../../api/client';
import { useApp } from '../../context/AppContext';

const LOSS_STEPS = ['Timing', 'Reason', 'Notes'];

export default function FeedbackModal({ target, open, onClose }) {
  const { actions } = useApp();
  const [delay, setDelay] = useState('');
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [step, setStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  if (!target) return null;
  const { signal, result } = target;
  const isLoss = result === 'LOSS';

  const reset = () => {
    setDelay('');
    setReason('');
    setNotes('');
    setStep(0);
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      await FeedbackAPI.submit({
        msgId: signal.msg_id,
        result,
        delay: delay ? Number(delay) : undefined,
        reason: reason || undefined,
        notes: notes || undefined,
        // Backend triggers AI analysis on its side for loss interviews.
        analysis: isLoss ? 'requested' : undefined,
      });
      handleClose();
    } catch (e) {
      actions.notifyError(e.message || 'Failed to submit feedback');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onClose={handleClose} maxWidth="xs" fullWidth>
      <DialogTitle>
        {isLoss ? 'Loss Interview' : 'Mark as Win'} — {signal.symbol}
      </DialogTitle>
      <DialogContent>
        {isLoss && (
          <Stepper activeStep={step} sx={{ mb: 3, mt: 1 }}>
            {LOSS_STEPS.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
        )}

        <Stack spacing={2}>
          {(!isLoss || step === 0) && (
            <TextField
              label="Entry delay (seconds)"
              type="number"
              value={delay}
              onChange={(e) => setDelay(e.target.value)}
              fullWidth
            />
          )}
          {isLoss && step === 1 && (
            <TextField
              label="Reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              fullWidth
              multiline
              minRows={2}
            />
          )}
          {isLoss && step === 2 && (
            <TextField
              label="Notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              fullWidth
              multiline
              minRows={3}
            />
          )}
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose}>Cancel</Button>
        {isLoss && step > 0 && (
          <Button onClick={() => setStep((s) => s - 1)}>Back</Button>
        )}
        {isLoss && step < LOSS_STEPS.length - 1 ? (
          <Button variant="contained" onClick={() => setStep((s) => s + 1)}>
            Next
          </Button>
        ) : (
          <Button variant="contained" onClick={handleSubmit} disabled={submitting}>
            Submit
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
}
