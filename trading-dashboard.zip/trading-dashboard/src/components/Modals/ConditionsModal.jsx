import React, { useEffect, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CircularProgress,
  Box,
} from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CancelIcon from '@mui/icons-material/Cancel';
import { SignalsAPI } from '../../api/client';
import { useApp } from '../../context/AppContext';

// Backend returns a text report with ✅/❌ markers per the spec. We parse it
// into lines here rather than assuming a structured shape, since the spec
// describes it as free text.
function parseReport(text) {
  if (!text) return [];
  return text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => ({
      pass: line.includes('✅'),
      label: line.replace(/✅|❌/g, '').trim(),
    }));
}

export default function ConditionsModal({ signal, open, onClose }) {
  const { actions } = useApp();
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState('');

  useEffect(() => {
    if (!open || !signal) return;
    setLoading(true);
    SignalsAPI.conditions(signal.symbol)
      .then((res) => setReport(res.data.report ?? res.data))
      .catch((e) => actions.notifyError(e.message || 'Failed to load conditions'))
      .finally(() => setLoading(false));
  }, [open, signal, actions]);

  if (!signal) return null;
  const items = parseReport(typeof report === 'string' ? report : '');

  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs" fullWidth>
      <DialogTitle>Conditions — {signal.symbol}</DialogTitle>
      <DialogContent>
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', py: 3 }}>
            <CircularProgress size={28} />
          </Box>
        ) : (
          <List dense>
            {items.map((item, i) => (
              <ListItem key={i} disableGutters>
                <ListItemIcon sx={{ minWidth: 32 }}>
                  {item.pass ? (
                    <CheckCircleIcon color="success" fontSize="small" />
                  ) : (
                    <CancelIcon color="error" fontSize="small" />
                  )}
                </ListItemIcon>
                <ListItemText primary={item.label} />
              </ListItem>
            ))}
          </List>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}
