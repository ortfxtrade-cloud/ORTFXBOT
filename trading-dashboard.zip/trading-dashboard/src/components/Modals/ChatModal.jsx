import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  ToggleButtonGroup,
  ToggleButton,
  Box,
  Paper,
  Typography,
  CircularProgress,
} from '@mui/material';
import { ChatAPI } from '../../api/client';
import { useApp } from '../../context/AppContext';

export default function ChatModal({ open, onClose }) {
  const { actions } = useApp();
  const [mode, setMode] = useState('chat');
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    const text = input.trim();
    if (!text) return;
    setMessages((m) => [...m, { role: 'user', text }]);
    setInput('');
    setSending(true);
    try {
      const res = await ChatAPI.send(text, mode);
      setMessages((m) => [...m, { role: 'assistant', text: res.data.reply ?? res.data }]);
    } catch (e) {
      actions.notifyError(e.message || 'Chat request failed');
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        Chat
        <ToggleButtonGroup
          size="small"
          value={mode}
          exclusive
          onChange={(_, v) => v && setMode(v)}
        >
          <ToggleButton value="chat">Chat</ToggleButton>
          <ToggleButton value="debug">Debug</ToggleButton>
        </ToggleButtonGroup>
      </DialogTitle>
      <DialogContent>
        <Box
          sx={{
            height: 320,
            overflowY: 'auto',
            display: 'flex',
            flexDirection: 'column',
            gap: 1,
            mb: 2,
          }}
        >
          {messages.length === 0 && (
            <Typography color="text.secondary" variant="body2">
              Ask about scanner behavior, a signal, or recent decisions.
            </Typography>
          )}
          {messages.map((m, i) => (
            <Paper
              key={i}
              sx={{
                p: 1.5,
                alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
                bgcolor: m.role === 'user' ? 'primary.dark' : 'background.default',
                maxWidth: '80%',
              }}
            >
              <Typography variant="body2">{m.text}</Typography>
            </Paper>
          ))}
        </Box>
        <Box sx={{ display: 'flex', gap: 1 }}>
          <TextField
            fullWidth
            size="small"
            placeholder="Type a message…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          />
          <Button
            variant="contained"
            onClick={handleSend}
            disabled={sending}
            sx={{ minWidth: 88 }}
          >
            {sending ? <CircularProgress size={18} color="inherit" /> : 'Send'}
          </Button>
        </Box>
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>Close</Button>
      </DialogActions>
    </Dialog>
  );
}
