import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Box,
  Chip,
  Switch,
  Typography,
  CircularProgress,
} from '@mui/material';
import { useApp } from '../../context/AppContext';
import { ControlAPI } from '../../api/client';

const statusMeta = {
  live: { label: 'Live', color: 'success' },
  polling: { label: 'Polling', color: 'warning' },
  connecting: { label: 'Connecting…', color: 'default' },
  offline: { label: 'Offline', color: 'error' },
};

export default function Topbar() {
  const { state, actions } = useApp();
  const [toggling, setToggling] = useState(false);
  const meta = statusMeta[state.connectionStatus] || statusMeta.connecting;

  const handleToggleScanner = async () => {
    setToggling(true);
    try {
      await ControlAPI.scanner(state.scannerRunning ? 'pause' : 'start');
      // Actual state flips via the scanner_status websocket event, not here.
    } catch (e) {
      actions.notifyError(e.message || 'Failed to update scanner');
    } finally {
      setToggling(false);
    }
  };

  return (
    <AppBar
      position="sticky"
      color="transparent"
      elevation={0}
      sx={{ borderBottom: '1px solid rgba(230,233,240,0.08)', backdropFilter: 'blur(6px)' }}
    >
      <Toolbar sx={{ gap: 2 }}>
        <Typography variant="body2" color="text.secondary">
          {state.pairs.length} pairs · {state.blockedPairs.length} blocked
        </Typography>

        <Box sx={{ flexGrow: 1 }} />

        <Chip size="small" label={meta.label} color={meta.color} variant="outlined" />

        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="body2" color="text.secondary">
            Scanner
          </Typography>
          {toggling ? (
            <CircularProgress size={20} />
          ) : (
            <Switch
              checked={state.scannerRunning}
              onChange={handleToggleScanner}
              color="success"
            />
          )}
        </Box>
      </Toolbar>
    </AppBar>
  );
}
