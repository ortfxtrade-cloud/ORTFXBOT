import React from 'react';
import {
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Box,
  Typography,
} from '@mui/material';
import DashboardIcon from '@mui/icons-material/DashboardOutlined';
import TrendingUpIcon from '@mui/icons-material/TrendingUpOutlined';
import ListAltIcon from '@mui/icons-material/ListAltOutlined';
import TuneIcon from '@mui/icons-material/TuneOutlined';
import BarChartIcon from '@mui/icons-material/BarChartOutlined';

const NAV_WIDTH = 220;

const items = [
  { key: 'dashboard', label: 'Dashboard', icon: <DashboardIcon /> },
  { key: 'signals', label: 'Signal Feed', icon: <TrendingUpIcon /> },
  { key: 'pairs', label: 'Pairs', icon: <ListAltIcon /> },
  { key: 'settings', label: 'Settings', icon: <TuneIcon /> },
  { key: 'stats', label: 'Statistics', icon: <BarChartIcon /> },
];

export default function Sidebar({ current, onNavigate }) {
  return (
    <Drawer
      variant="permanent"
      sx={{
        width: NAV_WIDTH,
        flexShrink: 0,
        [`& .MuiDrawer-paper`]: {
          width: NAV_WIDTH,
          boxSizing: 'border-box',
          borderRight: '1px solid rgba(230,233,240,0.08)',
        },
      }}
    >
      <Toolbar sx={{ px: 3 }}>
        <Typography variant="subtitle1" fontWeight={700}>
          Signal Scanner
        </Typography>
      </Toolbar>
      <Box sx={{ overflow: 'auto', mt: 1 }}>
        <List>
          {items.map((item) => (
            <ListItemButton
              key={item.key}
              selected={current === item.key}
              onClick={() => onNavigate(item.key)}
              sx={{ mx: 1, borderRadius: 2, mb: 0.5 }}
            >
              <ListItemIcon sx={{ minWidth: 40 }}>{item.icon}</ListItemIcon>
              <ListItemText primary={item.label} />
            </ListItemButton>
          ))}
        </List>
      </Box>
    </Drawer>
  );
}
