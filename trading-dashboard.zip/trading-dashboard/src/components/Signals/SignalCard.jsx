import React, { useState } from 'react';
import {
  Card,
  CardContent,
  CardActions,
  Box,
  Typography,
  Chip,
  Button,
  Collapse,
  Grid,
  IconButton,
  Tooltip,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import VolumeOffIcon from '@mui/icons-material/VolumeOff';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import { useApp } from '../../context/AppContext';
import { ControlAPI, PairsAPI } from '../../api/client';

function DirectionChip({ direction }) {
  const isBuy = direction === 'BUY';
  return (
    <Chip
      label={direction}
      size="small"
      color={isBuy ? 'success' : 'error'}
      sx={{ fontWeight: 700 }}
    />
  );
}

function Metric({ label, value }) {
  return (
    <Box>
      <Typography variant="caption" display="block">
        {label}
      </Typography>
      <Typography variant="body2" fontWeight={600}>
        {value ?? '—'}
      </Typography>
    </Box>
  );
}

export default function SignalCard({ signal, onPlaceTrade, onConditions, onQuickScan, onFeedback }) {
  const { actions } = useApp();
  const [expanded, setExpanded] = useState(false);
  const [busy, setBusy] = useState(false);

  const handleMute = async () => {
    setBusy(true);
    try {
      await ControlAPI.mute(signal.symbol);
    } catch (e) {
      actions.notifyError(e.message || `Failed to mute ${signal.symbol}`);
    } finally {
      setBusy(false);
    }
  };

  const handleRemove = async () => {
    try {
      await PairsAPI.remove(signal.symbol);
      actions.dispatch({ type: 'REMOVE_SIGNAL_SYMBOL', symbol: signal.symbol });
    } catch (e) {
      actions.notifyError(e.message || `Failed to remove ${signal.symbol}`);
    }
  };

  return (
    <Card>
      <CardContent sx={{ pb: 1 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <Typography variant="h6">{signal.symbol}</Typography>
          <DirectionChip direction={signal.direction} />
          <Box sx={{ flexGrow: 1 }} />
          <Typography variant="caption">{signal.entry_time}</Typography>
        </Box>

        <Grid container spacing={2} sx={{ mt: 0.5 }}>
          <Grid item xs={4}>
            <Metric label="RSI 5m" value={signal.rsi_5m} />
          </Grid>
          <Grid item xs={4}>
            <Metric label="RSI 1m" value={signal.rsi_1m} />
          </Grid>
          <Grid item xs={4}>
            <Metric
              label="Result"
              value={
                signal.result ? (
                  <Chip
                    size="small"
                    label={signal.result}
                    color={signal.result === 'WIN' ? 'success' : 'error'}
                  />
                ) : (
                  'Pending'
                )
              }
            />
          </Grid>
        </Grid>

        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={6} sm={3}>
              <Metric label="MACD 5m" value={signal.macd_5m} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <Metric label="Signal 5m" value={signal.signal_5m} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <Metric label="Diff 5m" value={signal.diff_5m} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <Metric label="MACD 1m" value={signal.macd_1m} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <Metric label="Signal 1m" value={signal.signal_1m} />
            </Grid>
            <Grid item xs={6} sm={3}>
              <Metric label="Diff 1m" value={signal.diff_1m} />
            </Grid>
          </Grid>
        </Collapse>
      </CardContent>

      <CardActions sx={{ px: 2, pb: 2, flexWrap: 'wrap', gap: 0.5 }}>
        <Button size="small" variant="contained" onClick={() => onPlaceTrade(signal)}>
          Place Trade
        </Button>
        <Button size="small" onClick={() => onConditions(signal)}>
          Conditions
        </Button>
        <Button size="small" onClick={() => onQuickScan(signal)}>
          Quick Scan
        </Button>
        <Button size="small" color="success" onClick={() => onFeedback(signal, 'WIN')}>
          Win
        </Button>
        <Button size="small" color="error" onClick={() => onFeedback(signal, 'LOSS')}>
          Loss
        </Button>

        <Box sx={{ flexGrow: 1 }} />

        <Tooltip title="Mute 30 min">
          <span>
            <IconButton size="small" onClick={handleMute} disabled={busy}>
              <VolumeOffIcon fontSize="small" />
            </IconButton>
          </span>
        </Tooltip>
        <Tooltip title="Remove pair">
          <IconButton size="small" onClick={handleRemove}>
            <DeleteOutlineIcon fontSize="small" />
          </IconButton>
        </Tooltip>
        <IconButton
          size="small"
          onClick={() => setExpanded((v) => !v)}
          sx={{ transform: expanded ? 'rotate(180deg)' : 'none', transition: '0.2s' }}
        >
          <ExpandMoreIcon fontSize="small" />
        </IconButton>
      </CardActions>
    </Card>
  );
}
