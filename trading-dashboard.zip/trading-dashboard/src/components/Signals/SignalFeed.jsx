import React, { useEffect, useState } from 'react';
import { Box, Stack, Typography, CircularProgress } from '@mui/material';
import { useApp } from '../../context/AppContext';
import SignalCard from './SignalCard';
import EntryTimeModal from '../Modals/EntryTimeModal';
import ConditionsModal from '../Modals/ConditionsModal';
import FeedbackModal from '../Modals/FeedbackModal';
import { SignalsAPI } from '../../api/client';

export default function SignalFeed() {
  const { state, actions } = useApp();
  const [entryTarget, setEntryTarget] = useState(null);
  const [conditionsTarget, setConditionsTarget] = useState(null);
  const [feedbackTarget, setFeedbackTarget] = useState(null); // { signal, result }

  useEffect(() => {
    actions.clearUnread();
  }, [actions]);

  const handleQuickScan = async (signal) => {
    try {
      await SignalsAPI.quickScan(signal.symbol);
      // Result arrives via the signal_update socket event; nothing to merge here.
    } catch (e) {
      actions.notifyError(e.message || `Quick scan failed for ${signal.symbol}`);
    }
  };

  if (state.loading.signals) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (state.signals.length === 0) {
    return (
      <Typography color="text.secondary" sx={{ py: 6, textAlign: 'center' }}>
        No signals yet. They'll appear here as soon as the scanner finds one.
      </Typography>
    );
  }

  return (
    <>
      <Stack spacing={2}>
        {state.signals.map((signal) => (
          <SignalCard
            key={signal.msg_id}
            signal={signal}
            onPlaceTrade={setEntryTarget}
            onConditions={setConditionsTarget}
            onQuickScan={handleQuickScan}
            onFeedback={(sig, result) => setFeedbackTarget({ signal: sig, result })}
          />
        ))}
      </Stack>

      <EntryTimeModal
        signal={entryTarget}
        open={Boolean(entryTarget)}
        onClose={() => setEntryTarget(null)}
      />
      <ConditionsModal
        signal={conditionsTarget}
        open={Boolean(conditionsTarget)}
        onClose={() => setConditionsTarget(null)}
      />
      <FeedbackModal
        target={feedbackTarget}
        open={Boolean(feedbackTarget)}
        onClose={() => setFeedbackTarget(null)}
      />
    </>
  );
}
