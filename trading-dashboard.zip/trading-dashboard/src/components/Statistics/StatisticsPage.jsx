import React from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  CircularProgress,
} from '@mui/material';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from 'chart.js';
import { useApp } from '../../context/AppContext';

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

function StatCard({ label, value }) {
  return (
    <Paper sx={{ p: 2.5 }}>
      <Typography variant="caption">{label}</Typography>
      <Typography variant="h5" fontWeight={700}>
        {value}
      </Typography>
    </Paper>
  );
}

export default function StatisticsPage() {
  const { state } = useApp();

  if (state.loading.stats) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
        <CircularProgress />
      </Box>
    );
  }

  const stats = state.stats ?? {};
  const winRate = stats.total_trades
    ? Math.round((stats.wins / stats.total_trades) * 100)
    : 0;

  const lossReasons = stats.loss_reasons ?? {}; // { reason: count }
  const chartData = {
    labels: Object.keys(lossReasons),
    datasets: [
      {
        label: 'Loss occurrences',
        data: Object.values(lossReasons),
        backgroundColor: '#EF5350',
        borderRadius: 4,
      },
    ],
  };

  return (
    <Box>
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={3}>
          <StatCard label="Win rate" value={`${winRate}%`} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatCard label="Total trades" value={stats.total_trades ?? 0} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatCard label="Wins" value={stats.wins ?? 0} />
        </Grid>
        <Grid item xs={6} sm={3}>
          <StatCard label="Losses" value={stats.losses ?? 0} />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              Average entry delay by pair
            </Typography>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Pair</TableCell>
                  <TableCell align="right">Avg delay (win)</TableCell>
                  <TableCell align="right">Avg delay (loss)</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {(stats.per_pair ?? []).map((row) => (
                  <TableRow key={row.symbol}>
                    <TableCell>{row.symbol}</TableCell>
                    <TableCell align="right">{row.avg_delay_win ?? '—'}s</TableCell>
                    <TableCell align="right">{row.avg_delay_loss ?? '—'}s</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              Loss reasons
            </Typography>
            {Object.keys(lossReasons).length === 0 ? (
              <Typography color="text.secondary" variant="body2">
                No loss feedback recorded yet.
              </Typography>
            ) : (
              <Bar
                data={chartData}
                options={{
                  responsive: true,
                  plugins: { legend: { display: false } },
                  scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
                }}
              />
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
