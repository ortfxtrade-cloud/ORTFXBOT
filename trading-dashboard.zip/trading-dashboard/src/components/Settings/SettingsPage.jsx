import React, { useEffect, useState } from 'react';
import {
  Box,
  Tabs,
  Tab,
  Paper,
  Grid,
  Typography,
  Slider,
  Button,
  MenuItem,
  TextField,
  CircularProgress,
} from '@mui/material';
import { useApp } from '../../context/AppContext';

const RSI_FIELDS = [
  { key: 'rsi_5m_buy', label: '5m Buy threshold' },
  { key: 'rsi_5m_sell', label: '5m Sell threshold' },
  { key: 'rsi_1m_buy', label: '1m Buy threshold' },
  { key: 'rsi_1m_sell', label: '1m Sell threshold' },
];

function RsiEditor({ values, onChange }) {
  return (
    <Grid container spacing={4}>
      {RSI_FIELDS.map((field) => (
        <Grid item xs={12} sm={6} key={field.key}>
          <Typography gutterBottom variant="body2" color="text.secondary">
            {field.label}: <strong>{values[field.key] ?? '—'}</strong>
          </Typography>
          <Slider
            value={values[field.key] ?? 50}
            onChange={(_, v) => onChange(field.key, v)}
            min={0}
            max={100}
            valueLabelDisplay="auto"
          />
        </Grid>
      ))}
    </Grid>
  );
}

export default function SettingsPage() {
  const { state, actions } = useApp();
  const [tab, setTab] = useState('global');
  const [global, setGlobal] = useState({});
  const [perPair, setPerPair] = useState({});
  const [selectedPair, setSelectedPair] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (state.settings) {
      setGlobal(state.settings.global ?? {});
      setPerPair(state.settings.perPair ?? {});
      const pairs = Object.keys(state.settings.perPair ?? {});
      if (pairs.length && !selectedPair) setSelectedPair(pairs[0]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.settings]);

  if (state.loading.settings) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', py: 6 }}>
        <CircularProgress />
      </Box>
    );
  }

  const currentPairValues = perPair[selectedPair] ?? {};

  const handleSave = async () => {
    setSaving(true);
    try {
      if (tab === 'global') {
        await actions.updateSettings({ scope: 'global', values: global });
      } else {
        await actions.updateSettings({
          scope: 'pair',
          symbol: selectedPair,
          values: currentPairValues,
        });
      }
    } catch (e) {
      actions.notifyError(e.message || 'Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Box sx={{ maxWidth: 720 }}>
      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 2 }}>
        <Tab value="global" label="Global" />
        <Tab value="pair" label="Per-Pair" />
      </Tabs>

      <Paper sx={{ p: 3 }}>
        {tab === 'global' ? (
          <RsiEditor
            values={global}
            onChange={(key, v) => setGlobal((g) => ({ ...g, [key]: v }))}
          />
        ) : (
          <>
            <TextField
              select
              size="small"
              label="Pair"
              value={selectedPair}
              onChange={(e) => setSelectedPair(e.target.value)}
              sx={{ mb: 3, minWidth: 200 }}
            >
              {state.pairs.map((p) => {
                const sym = p.symbol ?? p;
                return (
                  <MenuItem key={sym} value={sym}>
                    {sym}
                  </MenuItem>
                );
              })}
            </TextField>
            <RsiEditor
              values={currentPairValues}
              onChange={(key, v) =>
                setPerPair((pp) => ({
                  ...pp,
                  [selectedPair]: { ...pp[selectedPair], [key]: v },
                }))
              }
            />
          </>
        )}

        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
          <Button variant="contained" onClick={handleSave} disabled={saving}>
            {saving ? <CircularProgress size={20} color="inherit" /> : 'Save Settings'}
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}
