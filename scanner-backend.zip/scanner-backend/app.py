import logging
import threading

from flask import Flask
from flask_cors import CORS
from flask_socketio import SocketIO

import config
import scanner
from routes import pairs, signals, settings, stats, feedback, entry_time, chat, control

logging.basicConfig(level=logging.INFO)

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": config.CORS_ORIGINS}})

socketio = SocketIO(app, cors_allowed_origins=config.CORS_ORIGINS, async_mode="threading")
scanner.init(socketio)

app.register_blueprint(pairs.bp)
app.register_blueprint(signals.bp)
app.register_blueprint(settings.bp)
app.register_blueprint(stats.bp)
app.register_blueprint(feedback.bp)
app.register_blueprint(entry_time.bp)
app.register_blueprint(chat.bp)
app.register_blueprint(control.bp)


@app.route("/")
def health_check():
    return "Scanner backend is running."


@socketio.on("connect", namespace="/signals")
def on_connect():
    logging.info("Dashboard client connected to /signals")


@socketio.on("disconnect", namespace="/signals")
def on_disconnect():
    logging.info("Dashboard client disconnected from /signals")


if __name__ == "__main__":
    import os

    threading.Thread(target=scanner.scanner_engine, daemon=True).start()
    threading.Thread(target=scanner.exit_check_scheduler, daemon=True).start()

    port = int(os.environ.get("PORT", 5000))
    logging.info(f"Starting scanner backend on port {port}")
    socketio.run(app, host="0.0.0.0", port=port)
