import time
import random
import logging
from datetime import datetime

import pandas as pd
import yfinance as yf

import config
import state
from strategy import calculate_strategy, latest_1m_cross, is_spread_present_5m, get_oanda_spread_pips
from state import get_effective_settings
from feedback_store import record_feedback

logging.basicConfig(level=logging.INFO)

_socketio = None  # set via init()


def init(socketio):
    global _socketio
    _socketio = socketio


def _emit(event, payload):
    if _socketio:
        _socketio.emit(event, payload, namespace='/signals')


def _emit_blocked_update():
    _emit('blocked_update', state.get_blocked_pairs())


def emit_blocked_update():
    """Public entry point for routes (e.g. mute) to trigger a blocked_update push."""
    _emit_blocked_update()


def emit_scanner_status():
    _emit('scanner_status', {"running": state.STATE["running"]})


def scanner_engine():
    while True:
        if state.STATE["running"]:
            with state.data_lock:
                current_pairs = list(state.STRATEGY_PAIRS)
            random.shuffle(current_pairs)

            for symbol in current_pairs:
                try:
                    if not _handle_spread_filter(symbol):
                        continue

                    df = yf.Ticker(symbol).history(period="5d", interval="5m")
                    if len(df) < 50:
                        continue
                    m, s, h, rsi = calculate_strategy(df)
                    prev_diff = m.iloc[-1] - s.iloc[-1]
                    prev_diff_before = m.iloc[-2] - s.iloc[-2]

                    if not _handle_compression_filter(symbol, h):
                        continue

                    df_1m = yf.Ticker(symbol).history(period="1d", interval="1m")
                    if len(df_1m) < 30:
                        continue
                    m_1m, s_1m, h_1m, rsi_1m = calculate_strategy(df_1m)
                    diff_1m_series = m_1m - s_1m
                    cross_1m = latest_1m_cross(diff_1m_series)

                    settings = get_effective_settings(symbol)
                    rsi_val = rsi.iloc[-1]
                    rsi_1m_val = rsi_1m.iloc[-1]

                    confirm_bull = (
                        prev_diff_before < 0 and prev_diff > 0 and abs(prev_diff) >= 0.00001
                        and cross_1m == 'bull'
                        and settings["rsi_buy_min"] <= rsi_val <= settings["rsi_buy_max"]
                        and settings["rsi_1m_buy_min"] <= rsi_1m_val <= settings["rsi_1m_buy_max"]
                    )
                    confirm_bear = (
                        prev_diff_before > 0 and prev_diff < 0 and abs(prev_diff) >= 0.00001
                        and cross_1m == 'bear'
                        and settings["rsi_sell_min"] <= rsi_val <= settings["rsi_sell_max"]
                        and settings["rsi_1m_sell_min"] <= rsi_1m_val <= settings["rsi_1m_sell_max"]
                    )

                    if (confirm_bull or confirm_bear) and \
                            (time.time() - state.alert_cooldowns.get(symbol, 0) > 300):
                        _emit_new_signal(
                            symbol, "BUY" if confirm_bull else "SELL",
                            df, m, s, prev_diff, m_1m, s_1m, diff_1m_series,
                            rsi_val, rsi_1m_val,
                        )
                        state.alert_cooldowns[symbol] = time.time()

                    time.sleep(1)
                except Exception as e:
                    logging.error(f"Scanner error {symbol}: {e}")
                    time.sleep(2)

            time.sleep(config.SCAN_INTERVAL_SECONDS)
        else:
            time.sleep(5)


def _handle_spread_filter(symbol):
    """Returns True if the symbol is clear to scan this pass."""
    if symbol in state.spread_blocked_5m:
        blocked_info = state.spread_blocked_5m[symbol]
        if config.OANDA_API_KEY and config.OANDA_ACCOUNT_ID:
            spread_pips = get_oanda_spread_pips(symbol)
            if spread_pips is not None:
                if spread_pips <= config.MAX_SPREAD_PIPS:
                    blocked_info['low_spread_count'] = blocked_info.get('low_spread_count', 0) + 1
                    if blocked_info['low_spread_count'] >= config.UNBLOCK_CONSECUTIVE_CHECKS:
                        del state.spread_blocked_5m[symbol]
                        _emit_blocked_update()
                        logging.info(f"Unblocked {symbol} - OANDA spread {spread_pips} pips")
                else:
                    blocked_info['low_spread_count'] = 0
            elif time.time() - blocked_info['blocked_since'] > 1800:
                del state.spread_blocked_5m[symbol]
                _emit_blocked_update()
        elif time.time() - blocked_info['blocked_since'] > 1800:
            del state.spread_blocked_5m[symbol]
            _emit_blocked_update()

        if symbol in state.spread_blocked_5m:
            return False

    if is_spread_present_5m(symbol):
        state.spread_blocked_5m[symbol] = {'blocked_since': time.time(), 'low_spread_count': 0}
        _emit_blocked_update()
        return False

    return True


def _handle_compression_filter(symbol, hist_series):
    hist_abs = hist_series.abs()
    avg_hist_abs = hist_abs.tail(100).mean() if len(hist_abs) >= 100 else hist_abs.mean()
    current_abs = abs(hist_series.iloc[-1])
    low_threshold = avg_hist_abs * 0.20
    high_threshold = avg_hist_abs * 0.50

    state.compression_counter.setdefault(symbol, 0)
    state.compression_blocked.setdefault(symbol, False)

    if state.compression_blocked[symbol]:
        if current_abs > high_threshold:
            state.compression_blocked[symbol] = False
            state.compression_counter[symbol] = 0
            _emit_blocked_update()
            return True
        return False

    if current_abs < low_threshold:
        state.compression_counter[symbol] += 1
        if state.compression_counter[symbol] >= 10:
            state.compression_blocked[symbol] = True
            _emit_blocked_update()
            return False
    else:
        state.compression_counter[symbol] = 0

    return True


def _emit_new_signal(symbol, direction, df, m, s, prev_diff, m_1m, s_1m, diff_1m_series, rsi_val, rsi_1m_val):
    entry_dt = df.index[-1]
    msg_id = state.next_msg_id()

    signal = {
        "msg_id": msg_id,
        "symbol": symbol,
        "direction": direction,
        "entry_time": entry_dt.strftime("%H:%M"),
        "macd_5m": round(float(m.iloc[-1]), 5),
        "signal_5m": round(float(s.iloc[-1]), 5),
        "diff_5m": round(float(prev_diff), 5),
        "macd_1m": round(float(m_1m.iloc[-1]), 5),
        "signal_1m": round(float(s_1m.iloc[-1]), 5),
        "diff_1m": round(float(diff_1m_series.iloc[-1]), 5),
        "rsi_5m": round(float(rsi_val), 2),
        "rsi_1m": round(float(rsi_1m_val), 2),
        "result": None,
    }

    log_entry = dict(signal)
    log_entry.update({
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "entry_dt_iso": entry_dt.isoformat(),
        "entry_placed_time": "",
        "entry_delay_placed": 0,
        "loss_reason": "",
        "loss_notes": "",
        "analysis_result": "",
        "result": "",
    })
    with state.data_lock:
        state.signal_log.append(log_entry)

    _emit('new_signal', signal)


# --- Exit check scheduler (auto-grades a trade after EXIT_WINDOW_MINUTES) ---

def exit_check_scheduler():
    while True:
        now = time.time()
        due = [job for job in state.exit_check_jobs if job["check_time"] <= now]
        for job in due:
            _perform_exit_check(job)
        state.exit_check_jobs[:] = [j for j in state.exit_check_jobs if j["check_time"] > now]
        time.sleep(10)


def _perform_exit_check(job):
    symbol = job["symbol"]
    direction = job["direction"]
    entry_price = job["entry_price"]
    msg_id = job["msg_id"]

    try:
        check_dt = datetime.fromtimestamp(job["check_time"])
        df = yf.Ticker(symbol).history(period="2d", interval="1m")
        if df.empty:
            raise ValueError("No 1m data")
        df.index = df.index.tz_localize(None)
        idx = df.index.searchsorted(check_dt)
        exit_price = df.iloc[0]['Close'] if idx == 0 else df.iloc[idx - 1]['Close']
        if pd.isna(exit_price):
            exit_price = df['Close'].iloc[-1]
    except Exception as e:
        logging.error(f"Exit price fetch failed: {e}")
        try:
            exit_price = yf.Ticker(symbol).history(period="1d", interval="1m")['Close'].iloc[-1]
        except Exception:
            logging.error(f"Fallback price fetch also failed for {symbol}")
            return

    pip = 0.01 if "JPY" in symbol else 0.0001
    threshold = pip * config.PRICE_THRESHOLD_PIPS

    if direction == "BUY":
        result = "WIN" if exit_price >= entry_price + threshold else "LOSS" if exit_price <= entry_price - threshold else "NEUTRAL"
    else:
        result = "WIN" if exit_price <= entry_price - threshold else "LOSS" if exit_price >= entry_price + threshold else "NEUTRAL"

    entry = next((e for e in state.signal_log if e.get("msg_id") == msg_id), None)
    delay_sec = entry.get("entry_delay_placed", 0) if entry else 0

    success, updated_entry = record_feedback(
        msg_id, result, delay_sec, "auto",
        f"Entry: {entry_price:.5f}, Exit: {exit_price:.5f}",
        f"Auto-check {config.EXIT_WINDOW_MINUTES}m",
    )

    if success:
        _emit('signal_update', {
            "msg_id": msg_id,
            "result": result,
            "entry_price": round(float(entry_price), 5),
            "exit_price": round(float(exit_price), 5),
        })
