import logging
import requests
import config


def ask_ai_core(question, system_prompt="You are a helpful trading assistant. Be concise."):
    if not config.GEMINI_API_KEY:
        return "❌ AI is not configured (GEMINI_API_KEY missing)."
    try:
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"gemini-2.0-flash:generateContent?key={config.GEMINI_API_KEY}"
        )
        headers = {"Content-Type": "application/json"}
        prompt = f"{system_prompt}\n\nUser: {question}"
        data = {"contents": [{"parts": [{"text": prompt}]}]}
        response = requests.post(url, headers=headers, json=data, timeout=15)
        result = response.json()
        candidates = result.get("candidates", [])
        if candidates:
            return candidates[0]["content"]["parts"][0]["text"]
        return f"❌ AI error: {result}"
    except Exception as e:
        logging.error(f"AI core error: {e}")
        return f"❌ Error: {e}"
