from flask import Blueprint, request, jsonify

import state
from feedback_store import record_feedback
from ai import ask_ai_core

bp = Blueprint("feedback", __name__, url_prefix="/api/feedback")


@bp.post("")
def submit_feedback():
    body = request.get_json(force=True) or {}
    msg_id = body.get("msgId")
    result = body.get("result")
    delay = body.get("delay") or 0
    reason = body.get("reason") or ""
    notes = body.get("notes") or ""
    analysis_requested = bool(body.get("analysis"))

    if msg_id is None or result not in ("WIN", "LOSS"):
        return jsonify({"message": "msgId and a valid result (WIN/LOSS) are required"}), 400

    analysis_text = ""
    if result == "LOSS" and analysis_requested:
        entry = next((e for e in state.signal_log if e.get("msg_id") == msg_id), None)
        signal_details = ""
        if entry:
            signal_details = (
                f"Signal: {entry['direction']} {entry['symbol']}\n"
                f"5m Diff: {entry.get('diff_5m')}, 1m Diff: {entry.get('diff_1m')}, "
                f"5m RSI: {entry.get('rsi_5m')}, 1m RSI: {entry.get('rsi_1m')}"
            )
        prompt = (
            f"Analyze this trade signal that resulted in a loss.\n{signal_details}\n"
            f"User entered the trade {delay}s after the signal.\n"
            f"Reason given: {reason}\nAdditional notes: {notes or 'None'}\n\n"
            "Determine if the bot's signal criteria were likely flawed. If yes, suggest "
            "specific parameter adjustments (e.g., change RSI bounds). If the loss was "
            "likely due to external factors (spread, news, market noise), reply "
            "'No bot error detected.' Be concise."
        )
        analysis_text = ask_ai_core(
            prompt, "You are a trading bot debugger. Analyze the trade and give actionable advice."
        )

    success, entry = record_feedback(msg_id, result, delay, reason, notes, analysis_text)
    if not success:
        return jsonify({"message": "signal not found"}), 404

    return jsonify({"recorded": True, "analysis": analysis_text or None})
