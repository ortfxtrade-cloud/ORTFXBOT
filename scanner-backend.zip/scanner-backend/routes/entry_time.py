import re
from datetime import datetime, time as dt_time, timedelta

from flask import Blueprint, request, jsonify
import pandas as pd
import yfinance as yf

import config
import state

bp = Blueprint("entry_time", __name__, url_prefix="/api/entry_time")

TIME_RE = re.compile(r"^(\d{1,2}):(\d{2})$")


@bp.post("")
def record_entry_time():
    body = request.get_json(force=True) or {}
    msg_id = body.get("msgId")
    time_str = (body.get("time") or "").strip()

    match = TIME_RE.match(time_str)
    if msg_id is None or not match:
        return jsonify({"message": "msgId and time in HH:MM format are required"}), 400

    hour, minute = int(match.group(1)), int(match.group(2))
    if not (0 <= hour <= 23 and 0 <= minute <= 59):
        return jsonify({"message": "invalid time"}), 400

    entry = next((e for e in state.signal_log if e.get("msg_id") == msg_id), None)
    if not entry:
        return jsonify({"message": "signal not found"}), 404

    if entry.get("entry_placed_time"):
        return jsonify({"message": "trade already recorded for this signal"}), 409

    symbol = entry["symbol"]
    direction = entry["direction"]

    entry_dt = datetime.fromisoformat(entry["entry_dt_iso"])
    today = datetime.now().date()
    placed_dt = datetime.combine(today, dt_time(hour, minute))
    if placed_dt < entry_dt:
        placed_dt += timedelta(days=1)

    delay_sec = max(0, (placed_dt - entry_dt).total_seconds())
    entry["entry_placed_time"] = placed_dt.strftime("%H:%M")
    entry["entry_delay_placed"] = delay_sec

    try:
        df = yf.Ticker(symbol).history(period="2d", interval="1m")
        if df.empty:
            raise ValueError("No 1m data")
        df.index = df.index.tz_localize(None)
        idx = df.index.searchsorted(placed_dt)
        entry_price = df.iloc[0]["Close"] if idx == 0 else df.iloc[idx - 1]["Close"]
        if pd.isna(entry_price):
            entry_price = df["Close"].iloc[-1]
    except Exception:
        entry_price = yf.Ticker(symbol).history(period="1d", interval="1m")["Close"].iloc[-1]

    check_time = placed_dt.timestamp() + (config.EXIT_WINDOW_MINUTES * 60)
    state.exit_check_jobs.append({
        "msg_id": msg_id,
        "symbol": symbol,
        "direction": direction,
        "entry_price": float(entry_price),
        "check_time": check_time,
    })

    return jsonify({
        "recorded": True,
        "entry_placed_time": entry["entry_placed_time"],
        "delay_sec": delay_sec,
        "exit_check_at": datetime.fromtimestamp(check_time).strftime("%H:%M"),
    })
