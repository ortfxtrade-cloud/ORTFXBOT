from flask import Blueprint, request, jsonify
import yfinance as yf

import state

bp = Blueprint("pairs", __name__, url_prefix="/api/pairs")


@bp.get("")
def list_pairs():
    with state.data_lock:
        pairs = list(state.STRATEGY_PAIRS)
    return jsonify([{"symbol": p} for p in pairs])


@bp.post("")
def add_pair():
    body = request.get_json(force=True) or {}
    symbol = (body.get("symbol") or "").strip().upper()
    if not symbol:
        return jsonify({"message": "symbol is required"}), 400
    if "=X" not in symbol and "-" not in symbol and "^" not in symbol:
        # Best-effort FX suffix, matching the bot's convention. Leave
        # crypto/index/futures symbols (already containing -, ^) untouched.
        symbol = symbol + "=X"

    try:
        history = yf.Ticker(symbol).history(period="1d")
    except Exception as e:
        return jsonify({"message": f"Failed to validate symbol: {e}"}), 502

    if history is None or len(history) == 0:
        return jsonify({"message": f"{symbol} not found"}), 404

    with state.data_lock:
        if symbol not in state.STRATEGY_PAIRS:
            state.STRATEGY_PAIRS.append(symbol)

    return jsonify({"symbol": symbol}), 201


@bp.delete("/<symbol>")
def remove_pair(symbol):
    symbol = symbol.upper()
    with state.data_lock:
        if symbol in state.STRATEGY_PAIRS:
            state.STRATEGY_PAIRS.remove(symbol)
    return jsonify({"symbol": symbol, "removed": True})
