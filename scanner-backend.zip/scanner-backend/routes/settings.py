from flask import Blueprint, request, jsonify

import state

bp = Blueprint("settings", __name__, url_prefix="/api/settings")

RSI_KEYS = {
    "rsi_buy_min", "rsi_buy_max", "rsi_sell_min", "rsi_sell_max",
    "rsi_1m_buy_min", "rsi_1m_buy_max", "rsi_1m_sell_min", "rsi_1m_sell_max",
}


def _settings_payload():
    with state.data_lock:
        return {
            "global": dict(state.global_settings),
            "perPair": {sym: dict(vals) for sym, vals in state.pair_settings.items()},
        }


@bp.get("")
def get_settings():
    return jsonify(_settings_payload())


@bp.post("")
def update_settings():
    body = request.get_json(force=True) or {}
    scope = body.get("scope")
    values = body.get("values") or {}
    values = {k: v for k, v in values.items() if k in RSI_KEYS}

    if not values:
        return jsonify({"message": "no recognized RSI fields in values"}), 400

    for key in ("rsi_buy", "rsi_sell", "rsi_1m_buy", "rsi_1m_sell"):
        mn, mx = values.get(f"{key}_min"), values.get(f"{key}_max")
        if mn is not None and mx is not None and mn >= mx:
            return jsonify({"message": f"{key}_min must be less than {key}_max"}), 400

    with state.data_lock:
        if scope == "global":
            state.global_settings.update(values)
        elif scope == "pair":
            symbol = body.get("symbol")
            if not symbol:
                return jsonify({"message": "symbol is required for scope=pair"}), 400
            state.pair_settings.setdefault(symbol, {}).update(values)
        else:
            return jsonify({"message": "scope must be 'global' or 'pair'"}), 400

    return jsonify(_settings_payload())
