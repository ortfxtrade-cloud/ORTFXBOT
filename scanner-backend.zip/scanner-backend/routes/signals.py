from flask import Blueprint, request, jsonify

import state
from strategy import diagnose_pair, quick_scan_single

bp = Blueprint("signals", __name__, url_prefix="/api")


def _public_signal(entry):
    """Strip internal bookkeeping fields before sending to the frontend."""
    return {
        "msg_id": entry["msg_id"],
        "symbol": entry["symbol"],
        "direction": entry["direction"],
        "entry_time": entry.get("entry_time") or entry.get("entry_dt_iso", "")[11:16],
        "macd_5m": entry.get("macd_5m"),
        "signal_5m": entry.get("signal_5m"),
        "diff_5m": entry.get("diff_5m"),
        "macd_1m": entry.get("macd_1m"),
        "signal_1m": entry.get("signal_1m"),
        "diff_1m": entry.get("diff_1m"),
        "rsi_5m": entry.get("rsi_5m"),
        "rsi_1m": entry.get("rsi_1m"),
        "result": entry.get("result") or None,
    }


@bp.get("/signals/latest")
def latest_signals():
    limit = request.args.get("limit", default=20, type=int)
    with state.data_lock:
        entries = list(reversed(state.signal_log))[:limit]
    return jsonify([_public_signal(e) for e in entries])


@bp.get("/signals/<int:msg_id>")
def get_signal(msg_id):
    entry = next((e for e in state.signal_log if e.get("msg_id") == msg_id), None)
    if not entry:
        return jsonify({"message": "signal not found"}), 404
    return jsonify(_public_signal(entry))


@bp.get("/conditions/<symbol>")
def conditions(symbol):
    report = diagnose_pair(symbol.upper())
    return jsonify({"report": report})


@bp.get("/quick_scan/<symbol>")
def quick_scan(symbol):
    direction, result = quick_scan_single(symbol.upper())
    if direction is None:
        return jsonify({"message": result}), 502
    return jsonify({"direction": direction, "metrics": result})
