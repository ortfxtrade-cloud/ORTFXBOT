from flask import Blueprint, jsonify

import state

bp = Blueprint("stats", __name__, url_prefix="/api/stats")


@bp.get("")
def get_stats():
    with state.data_lock:
        graded = [e for e in state.signal_log if e.get("result") in ("WIN", "LOSS")]
        wins = [e for e in graded if e["result"] == "WIN"]
        losses = [e for e in graded if e["result"] == "LOSS"]

        loss_reasons = {}
        for e in losses:
            reason = e.get("loss_reason") or "unspecified"
            loss_reasons[reason] = loss_reasons.get(reason, 0) + 1

        per_pair = []
        for symbol, s in state.pair_entry_stats.items():
            avg_win = round(sum(s["wins"]) / len(s["wins"]), 1) if s["wins"] else None
            avg_loss = round(sum(s["losses"]) / len(s["losses"]), 1) if s["losses"] else None
            per_pair.append({
                "symbol": symbol,
                "avg_delay_win": avg_win,
                "avg_delay_loss": avg_loss,
            })

        return jsonify({
            "total_trades": len(graded),
            "wins": len(wins),
            "losses": len(losses),
            "loss_reasons": loss_reasons,
            "per_pair": per_pair,
        })
