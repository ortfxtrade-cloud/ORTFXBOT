import time
from flask import Blueprint, request, jsonify

import state
import scanner

bp = Blueprint("control", __name__, url_prefix="/api/control")


@bp.post("/scanner")
def control_scanner():
    body = request.get_json(force=True) or {}
    action = body.get("action")
    if action not in ("start", "pause"):
        return jsonify({"message": "action must be 'start' or 'pause'"}), 400

    state.STATE["running"] = (action == "start")
    scanner.emit_scanner_status()
    return jsonify({"running": state.STATE["running"]})


@bp.post("/mute/<symbol>")
def mute_pair(symbol):
    symbol = symbol.upper()
    state.alert_cooldowns[symbol] = time.time() + 1800
    scanner.emit_blocked_update()
    return jsonify({"symbol": symbol, "muted_until": state.alert_cooldowns[symbol]})
