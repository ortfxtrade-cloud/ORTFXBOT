from flask import Blueprint, request, jsonify

from ai import ask_ai_core

bp = Blueprint("chat", __name__, url_prefix="/api/chat")

SYSTEM_PROMPTS = {
    "chat": "You are a friendly and knowledgeable trading assistant. Be concise.",
    "debug": "You are a trading bot debugger. Analyze the signal details, explain what went wrong, and suggest improvements.",
}


@bp.post("")
def chat():
    body = request.get_json(force=True) or {}
    message = (body.get("message") or "").strip()
    mode = body.get("mode") if body.get("mode") in SYSTEM_PROMPTS else "chat"

    if not message:
        return jsonify({"message": "message is required"}), 400

    reply = ask_ai_core(message, SYSTEM_PROMPTS[mode])
    return jsonify({"reply": reply})
