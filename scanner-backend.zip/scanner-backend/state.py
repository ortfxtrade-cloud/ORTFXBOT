import threading
import itertools
import config

data_lock = threading.Lock()

STRATEGY_PAIRS = list(config.DEFAULT_PAIRS)
STATE = {"running": True}

alert_cooldowns = {}          # symbol -> unix ts of last alert (also used for mute)
spread_blocked_5m = {}        # symbol -> {"blocked_since": ts, "low_spread_count": int}
compression_counter = {}      # symbol -> int
compression_blocked = {}      # symbol -> bool

signal_log = []               # list of signal dicts, newest appended at the end
pair_loss_streak = {}
pair_entry_stats = {}         # symbol -> {"wins": [delay,...], "losses": [delay,...]}

pair_settings = {}            # symbol -> dict of rsi_* overrides
global_settings = dict(config.DEFAULT_RSI)

exit_check_jobs = []           # list of scheduled exit-check dicts

_msg_id_counter = itertools.count(1)


def next_msg_id():
    with data_lock:
        return next(_msg_id_counter)


def get_effective_settings(symbol):
    with data_lock:
        overrides = pair_settings.get(symbol, {})
        merged = dict(global_settings)
        merged.update(overrides)
        return merged


def get_blocked_pairs():
    """Unified view of everything currently blocked, for the frontend."""
    with data_lock:
        blocked = []
        now = __import__("time").time()
        for sym, info in spread_blocked_5m.items():
            blocked.append({"symbol": sym, "reason": "spread", "since": info["blocked_since"]})
        for sym, is_blocked in compression_blocked.items():
            if is_blocked:
                blocked.append({"symbol": sym, "reason": "compression", "since": None})
        for sym, cd in alert_cooldowns.items():
            if cd > now:
                blocked.append({"symbol": sym, "reason": "muted", "since": None, "until": cd})
        return blocked
