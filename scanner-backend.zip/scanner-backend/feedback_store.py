import os
import csv
import logging
import state


def record_feedback(msg_id, result, delay_sec=0, reason="", notes="", analysis=""):
    with state.data_lock:
        entry = next((e for e in state.signal_log if e.get("msg_id") == msg_id), None)
        if not entry:
            return False, None

        if delay_sec == 0 and entry.get("entry_delay_placed", 0) > 0:
            delay_sec = entry["entry_delay_placed"]

        entry["result"] = result
        entry["entry_delay_placed"] = delay_sec
        entry["loss_reason"] = reason
        entry["loss_notes"] = notes
        entry["analysis_result"] = analysis
        symbol = entry["symbol"]

        if result == "LOSS":
            state.pair_loss_streak[symbol] = state.pair_loss_streak.get(symbol, 0) + 1
        else:
            state.pair_loss_streak[symbol] = 0

        stats = state.pair_entry_stats.setdefault(symbol, {"wins": [], "losses": []})
        if result == "WIN":
            stats["wins"].append(delay_sec)
        elif result == "LOSS":
            stats["losses"].append(delay_sec)

        try:
            file_exists = os.path.isfile("signal_log.csv")
            with open("signal_log.csv", "a", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=list(entry.keys()))
                if not file_exists:
                    writer.writeheader()
                writer.writerow(entry)
        except Exception as e:
            logging.error(f"CSV write error: {e}")

        return True, dict(entry)
