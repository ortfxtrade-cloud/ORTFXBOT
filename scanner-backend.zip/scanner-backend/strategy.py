import logging
import time
import requests
import yfinance as yf

import config
from state import get_effective_settings

logging.basicConfig(level=logging.INFO)


def calculate_strategy(df):
    fast_ema = df['Close'].ewm(span=12, adjust=False).mean()
    slow_ema = df['Close'].ewm(span=26, adjust=False).mean()
    macd = fast_ema - slow_ema
    signal = macd.ewm(span=9, adjust=False).mean()
    hist = macd - signal
    delta = df['Close'].diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / 14, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / 14, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, 1e-10)
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return macd, signal, hist, rsi


def latest_1m_cross(diff_series):
    diffs = list(diff_series)
    for i in range(len(diffs) - 1, 0, -1):
        if diffs[i - 1] < 0 and diffs[i] > 0:
            return 'bull'
        elif diffs[i - 1] > 0 and diffs[i] < 0:
            return 'bear'
    return None


def is_spread_present_5m(symbol):
    try:
        df = yf.Ticker(symbol).history(period="1d", interval="5m")
        if len(df) < 10:
            return False
        last_candles = df.tail(5)
        high_low_range = last_candles['High'] - last_candles['Low']
        avg_range = high_low_range.mean()
        avg_price = last_candles['Close'].mean()
        body_size = abs(last_candles['Close'] - last_candles['Open'])
        avg_body = body_size.mean()
        condition1 = avg_price > 0 and avg_range < avg_price * 0.0002
        condition2 = avg_price > 0 and avg_body < avg_price * 0.00005
        condition3 = df.iloc[-1]['High'] == df.iloc[-1]['Low']
        return sum([condition1, condition2, condition3]) >= 2
    except Exception as e:
        logging.error(f"5m spread check error {symbol}: {e}")
        return False


def get_oanda_spread_pips(symbol):
    if not config.OANDA_API_KEY or not config.OANDA_ACCOUNT_ID:
        return None
    instrument = symbol.replace("=X", "")
    base, quote = instrument[:3], instrument[3:]
    oanda_symbol = f"{base}_{quote}"
    try:
        url = f"https://api-fxtrade.oanda.com/v3/instruments/{oanda_symbol}/pricing"
        headers = {"Authorization": f"Bearer {config.OANDA_API_KEY}"}
        params = {"instruments": oanda_symbol}
        response = requests.get(url, headers=headers, params=params, timeout=5)
        data = response.json()
        prices = data.get("prices", [])
        if not prices:
            return None
        bid = float(prices[0]["bids"][0]["price"])
        ask = float(prices[0]["asks"][0]["price"])
        spread = ask - bid
        pip_size = 0.01 if "JPY" in quote else 0.0001
        return round(spread / pip_size, 2)
    except Exception as e:
        logging.error(f"OANDA spread check error {symbol}: {e}")
        return None


def quick_scan_single(symbol):
    """Returns (direction, payload_dict_or_error_string)."""
    try:
        df = yf.Ticker(symbol).history(period="5d", interval="5m")
        if len(df) < 50:
            return None, "Insufficient data"
        m, s, h, rsi = calculate_strategy(df)
        prev_diff = m.iloc[-1] - s.iloc[-1]
        prev_diff_before = m.iloc[-2] - s.iloc[-2]

        df_1m = yf.Ticker(symbol).history(period="1d", interval="1m")
        if len(df_1m) < 30:
            return None, "Insufficient 1m data"
        m_1m, s_1m, h_1m, rsi_1m = calculate_strategy(df_1m)
        diff_1m_series = m_1m - s_1m
        cross_1m = latest_1m_cross(diff_1m_series)

        settings = get_effective_settings(symbol)
        rsi_val = rsi.iloc[-1]
        rsi_1m_val = rsi_1m.iloc[-1]

        is_bull = (prev_diff_before < 0) and (prev_diff > 0) and (cross_1m == 'bull')
        is_bear = (prev_diff_before > 0) and (prev_diff < 0) and (cross_1m == 'bear')

        payload = {
            "symbol": symbol,
            "macd_5m": round(float(m.iloc[-1]), 5),
            "signal_5m": round(float(s.iloc[-1]), 5),
            "diff_5m": round(float(prev_diff), 5),
            "macd_1m": round(float(m_1m.iloc[-1]), 5),
            "signal_1m": round(float(s_1m.iloc[-1]), 5),
            "diff_1m": round(float(diff_1m_series.iloc[-1]), 5),
            "rsi_5m": round(float(rsi_val), 2),
            "rsi_1m": round(float(rsi_1m_val), 2),
        }

        if is_bull and settings["rsi_buy_min"] <= rsi_val <= settings["rsi_buy_max"] \
                and settings["rsi_1m_buy_min"] <= rsi_1m_val <= settings["rsi_1m_buy_max"]:
            return "BUY", payload
        elif is_bear and settings["rsi_sell_min"] <= rsi_val <= settings["rsi_sell_max"] \
                and settings["rsi_1m_sell_min"] <= rsi_1m_val <= settings["rsi_1m_sell_max"]:
            return "SELL", payload
        return "NEUTRAL", payload
    except Exception as e:
        return None, str(e)


def diagnose_pair(symbol):
    """Returns a newline-delimited ✅/❌ report, same shape the frontend's
    ConditionsModal already parses."""
    from state import spread_blocked_5m, compression_blocked, compression_counter, alert_cooldowns
    try:
        df = yf.Ticker(symbol).history(period="5d", interval="5m")
        if len(df) < 50:
            return "❌ Not enough data to evaluate."
        m, s, h, rsi = calculate_strategy(df)
        prev_diff = m.iloc[-1] - s.iloc[-1]
        prev_diff_before = m.iloc[-2] - s.iloc[-2]

        df_1m = yf.Ticker(symbol).history(period="1d", interval="1m")
        if len(df_1m) < 30:
            return "❌ Not enough 1m data."
        m_1m, s_1m, h_1m, rsi_1m = calculate_strategy(df_1m)
        diff_1m_series = m_1m - s_1m
        cross_1m = latest_1m_cross(diff_1m_series)

        settings = get_effective_settings(symbol)
        rsi_val = rsi.iloc[-1]
        rsi_1m_val = rsi_1m.iloc[-1]

        spread_blocked = symbol in spread_blocked_5m or is_spread_present_5m(symbol)
        spread_ok = not spread_blocked

        hist_abs = h.abs()
        avg_hist_abs = hist_abs.tail(100).mean() if len(hist_abs) >= 100 else hist_abs.mean()
        current_abs = abs(h.iloc[-1])
        low_thresh = avg_hist_abs * 0.20
        if compression_blocked.get(symbol):
            compression_ok = False
        else:
            compression_ok = not (current_abs < low_thresh and compression_counter.get(symbol, 0) >= 10)

        bull_5m = (prev_diff_before < 0) and (prev_diff > 0) and (abs(prev_diff) >= 0.00001)
        bear_5m = (prev_diff_before > 0) and (prev_diff < 0) and (abs(prev_diff) >= 0.00001)
        bull_1m = (cross_1m == 'bull')
        bear_1m = (cross_1m == 'bear')

        rsi5_buy = settings["rsi_buy_min"] <= rsi_val <= settings["rsi_buy_max"]
        rsi5_sell = settings["rsi_sell_min"] <= rsi_val <= settings["rsi_sell_max"]
        rsi1_buy = settings["rsi_1m_buy_min"] <= rsi_1m_val <= settings["rsi_1m_buy_max"]
        rsi1_sell = settings["rsi_1m_sell_min"] <= rsi_1m_val <= settings["rsi_1m_sell_max"]

        cooldown_ok = (time.time() - alert_cooldowns.get(symbol, 0)) > 300

        lines = [
            f"Spread filter: {'✅' if spread_ok else '❌'}",
            f"MACD compression: {'✅' if compression_ok else '❌'}",
            f"5m MACD cross: {'✅ Bullish' if bull_5m else '✅ Bearish' if bear_5m else '❌ None'}",
            f"Latest 1m cross: {'✅ Bullish' if bull_1m else '✅ Bearish' if bear_1m else '❌ None'}",
            f"5m RSI ({rsi_val:.1f}): {'✅' if (rsi5_buy or rsi5_sell) else '❌'}",
            f"1m RSI ({rsi_1m_val:.1f}): {'✅' if (rsi1_buy or rsi1_sell) else '❌'}",
            f"Cooldown: {'✅' if cooldown_ok else '❌'}",
        ]
        if bull_5m and bull_1m and rsi5_buy and rsi1_buy and spread_ok and compression_ok and cooldown_ok:
            lines.append("✅ BUY signal READY")
        elif bear_5m and bear_1m and rsi5_sell and rsi1_sell and spread_ok and compression_ok and cooldown_ok:
            lines.append("✅ SELL signal READY")
        else:
            lines.append("❌ No signal ready yet")
        return "\n".join(lines)
    except Exception as e:
        return f"❌ Error: {e}"
