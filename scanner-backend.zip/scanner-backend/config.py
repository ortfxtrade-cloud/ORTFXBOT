import os
from dotenv import load_dotenv

load_dotenv()  # loads .env in local dev; no-op if it doesn't exist (e.g. in prod)

# --- Secrets: environment only. Never hardcode these. ---
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
OANDA_API_KEY = os.environ.get("OANDA_API_KEY", "")
OANDA_ACCOUNT_ID = os.environ.get("OANDA_ACCOUNT_ID", "")

# If you still also want the Telegram bot running alongside the API,
# set TELEGRAM_TOKEN and CHAT_ID and wire telegram_bot.py back in — it's
# intentionally left out of this backend so the dashboard is the only
# client talking to these globals.
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN", "")

MAX_SPREAD_PIPS = float(os.environ.get("MAX_SPREAD_PIPS", "3.0"))
UNBLOCK_CONSECUTIVE_CHECKS = int(os.environ.get("UNBLOCK_CONSECUTIVE_CHECKS", "2"))
EXIT_WINDOW_MINUTES = int(os.environ.get("EXIT_WINDOW_MINUTES", "5"))
PRICE_THRESHOLD_PIPS = float(os.environ.get("PRICE_THRESHOLD_PIPS", "0.5"))
SCAN_INTERVAL_SECONDS = int(os.environ.get("SCAN_INTERVAL_SECONDS", "30"))

CORS_ORIGINS = os.environ.get("CORS_ORIGINS", "*")

DEFAULT_RSI = {
    "rsi_buy_min": 30, "rsi_buy_max": 40,
    "rsi_sell_min": 50, "rsi_sell_max": 70,
    "rsi_1m_buy_min": 30, "rsi_1m_buy_max": 40,
    "rsi_1m_sell_min": 50, "rsi_1m_sell_max": 70,
}

DEFAULT_PAIRS = [
    "EURUSD=X", "GBPUSD=X", "USDJPY=X", "USDCHF=X", "AUDUSD=X",
    "NZDUSD=X", "USDCAD=X", "EURGBP=X", "EURJPY=X", "EURCHF=X",
    "EURAUD=X", "EURNZD=X", "EURCAD=X", "GBPJPY=X", "GBPCHF=X",
    "GBPAUD=X", "GBPNZD=X", "GBPCAD=X", "CHFJPY=X", "CADJPY=X",
    "AUDJPY=X", "NZDJPY=X", "AUDNZD=X", "AUDCAD=X", "AUDCHF=X",
    "NZDCAD=X", "NZDCHF=X", "CADCHF=X",
]
