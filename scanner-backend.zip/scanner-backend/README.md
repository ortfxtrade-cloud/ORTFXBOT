# Scanner Backend

Flask + Socket.IO backend for the Signal Scanner Dashboard, ported from the
original Telegram bot. Same MACD/RSI strategy, spread filter, MACD
compression filter, and auto exit-check logic — exposed over REST + a
`/signals` Socket.IO namespace instead of Telegram.

## ⚠️ Before you run this

The Telegram bot source this was built from had a live bot token and a
Gemini API key hardcoded in plaintext. If those were real and shared
anywhere, **rotate them now**:
- Telegram: message @BotFather → `/revoke`
- Gemini: regenerate the key in Google AI Studio

This backend reads all secrets from environment variables only — nothing
is hardcoded. Copy `.env.example` to `.env` and fill in your (new) keys.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env   # fill in GEMINI_API_KEY at minimum
python app.py
```

Runs on `:5000` by default, matching the frontend's Vite proxy config.

## What changed vs. the original bot

- All Telegram-specific code (keyboards, callback handlers, message
  handlers, `bot.send_message`) is removed. The scanner now emits
  Socket.IO events (`new_signal`, `blocked_update`, `scanner_status`,
  `signal_update`) instead of sending Telegram messages.
- `msg_id` is now an internal incrementing counter instead of a Telegram
  message ID, since there's no Telegram message to attach to.
- The manual "reply with 15:35" entry-time flow and the step-by-step loss
  interview chat flow are now single REST calls (`POST /api/entry_time`,
  `POST /api/feedback` with `analysis: true`) — the frontend's modals
  collect the same information the Telegram flow did, just via form
  fields instead of chained bot replies.
- The strategy math (`calculate_strategy`, `latest_1m_cross`), the spread
  filter (`is_spread_present_5m`, OANDA hybrid unblock logic), and the
  MACD compression filter are unchanged from the original bot.

## ⚠️ Known gap vs. the frontend I scaffolded earlier

The original bot's RSI settings are **min/max ranges** (e.g. buy RSI
30–40), and that's what this backend implements (`GET/POST
/api/settings` uses `rsi_buy_min`, `rsi_buy_max`, etc.). The frontend's
`SettingsPage.jsx` from the earlier scaffold used **single slider
values** (`rsi_5m_buy`, `rsi_5m_sell`, ...), which doesn't match. You'll
want to update `SettingsPage.jsx` to use paired min/max sliders (8
fields total: 4 parameters × min/max) to match this backend's real
behavior — happy to make that change if you'd like.

## Notes / simplifications

- All state (pairs, signals, settings, blocked lists) is in-memory and
  resets on restart, same as the original bot. If you need persistence
  across deploys, that's a natural next step (SQLite would be enough).
- Symbol validation on `POST /api/pairs` calls `yf.Ticker(...).history()`
  synchronously, so adding a pair has a network round-trip. Fine for a
  personal dashboard; consider making it async if this becomes multi-user.
- `is_spread_present_5m` mutations aren't behind `data_lock` in the
  scanner loop, matching the original bot's behavior — this is safe
  enough for a single scanner thread but would need locking if you ever
  parallelize the scan loop.
